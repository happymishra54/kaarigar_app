import 'package:flutter/material.dart';

import '../../models/worker_service_model.dart';


class EditServiceScreen extends StatelessWidget {

  final WorkerServiceModel service;


  const EditServiceScreen({
    super.key,
    required this.service,
  });


  @override
  Widget build(BuildContext context) {


    return Scaffold(

      appBar: AppBar(
        title: const Text(
          "Edit Service",
        ),
      ),


      body: Padding(

        padding:
            const EdgeInsets.all(20),


        child: Column(

          crossAxisAlignment:
              CrossAxisAlignment.start,


          children: [


            Text(

              service.title,

              style:
                  const TextStyle(

                    fontSize:22,

                    fontWeight:
                        FontWeight.bold,

                  ),

            ),


            const SizedBox(height:20),


            Text(
              service.description ?? "",
            ),


            const SizedBox(height:20),


            Text(
              "Price: ₹${service.price}",
            ),


          ],

        ),

      ),

    );


  }

}